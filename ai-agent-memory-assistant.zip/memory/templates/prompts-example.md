﻿请读�?memory/memory.md，载入项目长期记忆�?若存�?knowledge/*、decisions/*、roadmap.md、changelog.md，请一并纳入上下文�?应用从MVP 开始继续，优先高保真原型测试开始�












